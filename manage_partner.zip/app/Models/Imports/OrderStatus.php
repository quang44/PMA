<?php

namespace App\Models\Imports;

use Illuminate\Database\Eloquent\Model;

class OrderStatus extends Model
{
    protected $fillable = [
        'status'
    ];
}
