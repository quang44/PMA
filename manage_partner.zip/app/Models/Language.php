<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use App;

class Language extends Model
{
  //
}
